#ifndef MY_DELAY_H_
#define MY_DELAY_H_

#include "stm32f10x.h"

void delay_init(void);
void delay_ms(uint32_t u32Time);

#endif
